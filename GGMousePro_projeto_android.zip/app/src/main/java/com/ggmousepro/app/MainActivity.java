package com.ggmousepro.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout page;
    private TextView status;
    private int blue = Color.rgb(25,118,210);
    private int ink = Color.rgb(28,42,58);
    private int muted = Color.rgb(102,119,136);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(244,248,252));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        prefs = getSharedPreferences("ggmouse", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(244,248,252));
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(page);
        setContentView(scroll);
        buildUi();
    }

    private void buildUi() {
        TextView brand = new TextView(this);
        brand.setText("GG MOUSE PRO");
        brand.setTextColor(blue); brand.setTextSize(25); brand.setTypeface(null, Typeface.BOLD);
        page.addView(brand);
        TextView subtitle = new TextView(this);
        subtitle.setText("PAINEL DE CONFIGURAÇÃO • FREE FIRE");
        subtitle.setTextColor(muted); subtitle.setTextSize(11);
        subtitle.setPadding(0, dp(4), 0, dp(18)); page.addView(subtitle);

        LinearLayout hero = card();
        TextView title = new TextView(this);
        title.setText("Seu painel gamer");
        title.setTextColor(ink); title.setTextSize(20); title.setTypeface(null, Typeface.BOLD);
        hero.addView(title);
        TextView desc = new TextView(this);
        desc.setText("Organize suas preferências de jogo em um só lugar.");
        desc.setTextColor(muted); desc.setTextSize(14); desc.setPadding(0, dp(7), 0, 0);
        hero.addView(desc); page.addView(hero);

        section("SENSIBILIDADE");
        addSlider("Geral", "sens_geral", 0, 200, 100);
        addSlider("Ponto vermelho", "sens_red", 0, 200, 90);
        addSlider("Mira 2x", "sens_2x", 0, 200, 85);
        addSlider("Mira 4x", "sens_4x", 0, 200, 75);

        section("MOUSE E TECLADO");
        LinearLayout map = card();
        addInfo(map, "Mouse", "Conecte um mouse USB ou Bluetooth nas configurações do Android.");
        addInfo(map, "Teclado", "Use um teclado compatível conectado ao celular.");
        addInfo(map, "Mapeamento", "Este protótipo não injeta toques nem remapeia controles dentro do Free Fire.");
        page.addView(map);

        section("PERFIL");
        LinearLayout profile = card();
        addInfo(profile, "Perfil atual", "Free Fire • Personalizado");
        Button save = new Button(this); save.setText("SALVAR CONFIGURAÇÕES");
        save.setTextColor(Color.WHITE); save.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        profile.addView(save);
        status = new TextView(this); status.setText("As alterações ficam salvas neste aparelho.");
        status.setTextColor(muted); status.setTextSize(12); status.setPadding(0, dp(8), 0, 0);
        profile.addView(status); page.addView(profile);
        save.setOnClickListener(v -> {
            // SeekBar values are saved as they change.
            status.setText("Configurações salvas neste aparelho.");
        });

        TextView foot = new TextView(this);
        foot.setText("GG Mouse Pro • Versão inicial de demonstração");
        foot.setTextColor(muted); foot.setTextSize(11); foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(22), 0, 0); page.addView(foot);
    }

    private void section(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(blue);
        t.setTextSize(12); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(2, dp(20), 0, dp(9)); page.addView(t);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(15), dp(16), dp(15));
        c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(4); c.setLayoutParams(lp);
        return c;
    }

    private void addSlider(String label, String key, int min, int max, int fallback) {
        LinearLayout c = card();
        TextView t = new TextView(this); t.setText(label); t.setTextColor(ink);
        t.setTextSize(15); t.setTypeface(null, Typeface.BOLD); c.addView(t);
        SeekBar seek = new SeekBar(this); seek.setMax(max-min);
        seek.setProgress(prefs.getInt(key, fallback)-min);
        TextView value = new TextView(this); value.setText(String.valueOf(seek.getProgress()+min));
        value.setTextColor(muted); value.setTextSize(12);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                value.setText(String.valueOf(p+min));
                if (user) prefs.edit().putInt(key, p+min).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        c.addView(seek); c.addView(value); page.addView(c);
    }

    private void addInfo(LinearLayout parent, String heading, String body) {
        TextView h = new TextView(this); h.setText(heading); h.setTextColor(ink);
        h.setTextSize(15); h.setTypeface(null, Typeface.BOLD); parent.addView(h);
        TextView d = new TextView(this); d.setText(body); d.setTextColor(muted);
        d.setTextSize(13); d.setPadding(0, dp(4), 0, dp(13)); parent.addView(d);
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
